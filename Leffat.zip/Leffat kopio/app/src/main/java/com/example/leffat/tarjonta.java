package com.example.leffat;

public class tarjonta {

    private String tarjonta = "nimi";



    public tarjonta(String n) {

        tarjonta = n;


    }

    public String getTarjontaNimi() {

        return tarjonta;


    }


}