package com.example.internetselain;

public class browseractions {

    private String webpage = "nimi";



    public browseractions(String n) {

        webpage = n;


    }

    public String getName() {

        return webpage;


    }










}
